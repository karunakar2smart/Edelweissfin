import React, { startTransition, useRef } from "react";
import { Col, Container, Row } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { modal, numberOfSundays } from "../../Store/Slices/userSlice";
import ListUser from "../UI/ListUser";

const Datepicker = () => {
 const dispatch = useDispatch();
 const firstDobref = useRef();
 const secondDobref = useRef();
 const submitHandler = (e) => {
  e.preventDefault();
  const firstDate = firstDobref.current.value;
  const secondDate = secondDobref.current.value;
  const enteredDates = {
   firstDate,
   secondDate,
  };
  dispatch(numberOfSundays(enteredDates));
  dispatch(modal());
  firstDobref.current.value = "";
  secondDobref.current.value = "";
 };
 const clearHandler = () => {
  firstDobref.current.value = "";
  secondDobref.current.value = "";
 };
 return (
  <>
   <Container fluid="md" className="mt-5">
    {/* CardContainer */}
    <Container>
     <Row>
      <Container fluid className="p-2 formContainer">
       <span className="text-white">
        <Link to="/" className="text-warning m-3 p-1">
         {" "}
         Go Back
        </Link>
       </span>
       <h3 className="card-title mt-3 mb-5 comment text-white font-weight-bold text-center">
        Find out Number of sundays between two Dates
       </h3>
       <form className="needs-validation p-1 mb-3" onSubmit={submitHandler}>
        <Row>
         {/* <!-- DOB --> */}
         <Col className="col-12 col-lg-6 mb-3 col-sm-12 col-md-6">
          <label className="text-white m-3">Select First Date</label>
          <input
           type="date"
           className="form-control p-4 rounded-0 inputField border-0"
           placeholder="Date of Birth"
           id="dob"
           ref={firstDobref}
           required
          />
         </Col>

         <Col className="col-12 col-lg-6 mb-3 col-sm-12 col-md-6">
          <label className="text-white m-3">Select Second Date</label>
          <input
           type="date"
           className="form-control p-4 rounded-0 inputField border-0"
           placeholder="Date of Birth"
           id="dob"
           ref={secondDobref}
           required
          />
         </Col>
        </Row>
        <Row className="text-center">
         <Col className="col-12 col-lg-6">
          <button
           className="btn w-100 mt-4 rounded-2 p-3 pl-4 pr-4 submitButton text-white font-weight-bold btn-primary"
           type="submit"
           id="submit">
           Submit
          </button>
         </Col>
         <Col className="col-12 col-lg-6">
          <button
           className="btn w-100 mt-4 rounded-2 p-3 pl-4 pr-4 submitButton text-white font-weight-bold float-right bg-success"
           type="reset"
           onClick={clearHandler}>
           RESET FORM INPUTS
          </button>
         </Col>
        </Row>
       </form>
      </Container>
     </Row>
    </Container>

    <hr />
    <ListUser />
   </Container>
  </>
 );
};

export default Datepicker;
