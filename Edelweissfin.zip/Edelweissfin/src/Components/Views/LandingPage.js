import React from "react";
import { Container, Row } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { storeSlice } from "../../Store/Slices/userSlice";
import FormContainer from "../UI/Form";

const LandingPage = () => {
 const dispatch = useDispatch();
 const incomingDataHandler = (enteredData) => {
  dispatch(storeSlice(enteredData));
 };

 return (
  <>
   <Container fluid="md" className="mt-5">
    {/* CardContainer */}
    <Container>
     <Row>
      <Container fluid className="p-2 formContainer">
       {/* FormContainer */}
       <FormContainer incomingDataHandler={incomingDataHandler} />
      </Container>
     </Row>
    </Container>
   </Container>
  </>
 );
};

export default LandingPage;
