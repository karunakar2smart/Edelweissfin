import React from "react";
import { Button, Card, Container } from "react-bootstrap";
import { useSelector } from "react-redux";
import userSlice from "../../Store/Slices/userSlice";
import ModalContainer from "./Modal";

const ListUser = () => {
 const user = useSelector((state) => state.userSlice.user);
 const sundaysCount = useSelector((state) => state.userSlice.userDates);
 const editHandler = () => {};
 console.log(sundaysCount, "sundaysCount");
 return (
  <>
   <Container>
    {sundaysCount &&
     user.map((i) => {
      const { Dob, Email, FirstName, Gender, PhoneNumber, id } = i;
      return (
       <Card
        key={id}
        className="mt-3 mb-3 text-white p-2 border-0 rounded-0 comment ">
        <Card.Body className="m-auto">
         {/* <Card.Link>
          <Button
           type="Button"
           style={{ float: "right" }}
           onClick={editHandler}>
           {counter + 1}
          </Button>
         </Card.Link> */}
         <Card.Title>Name: {FirstName}</Card.Title>
         <Card.Title>Email: {Email}</Card.Title>
         <Card.Title>Gender: {Gender}</Card.Title>
         <Card.Title>Date Of Birth: {Dob}</Card.Title>
         <Card.Title>PhoneNumber: {PhoneNumber}</Card.Title>
        </Card.Body>
       </Card>
      );
     })}
   </Container>
   <ModalContainer />
  </>
 );
};

export default ListUser;
