const Navigation = () => {
 return (
  <>
   <nav className="container text-white m-auto text-center mt-3 mb-3 p-3">
    <h4>Made in Love with Edelweissfin </h4>
   </nav>
  </>
 );
};

export default Navigation;
