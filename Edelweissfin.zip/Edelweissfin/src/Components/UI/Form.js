import React, { useRef } from "react";
import { Col, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";

const FormContainer = (props) => {
 const navigate = useNavigate();
 const firstnameref = useRef();
 const phonenumberref = useRef();
 const emailref = useRef();
 const dobref = useRef();
 const genderref = useRef();

 const submitHandler = (e) => {
  e.preventDefault();

  let firstName = firstnameref.current.value;
  let phoneNumber = phonenumberref.current.value;
  let email = emailref.current.value;
  let dob = dobref.current.value;
  let gender = genderref.current.value;

  const incomingInputs = {
   id: new Date().valueOf(),
   FirstName: firstName,
   PhoneNumber: phoneNumber,
   Email: email,
   Dob: dob,
   Gender: gender,
  };

  props.incomingDataHandler(incomingInputs);
  navigate("/datepicker");
  firstnameref.current.value = "";
  phonenumberref.current.value = "";
  emailref.current.value = "";
  dobref.current.value = "";
  genderref.current.value = "";
 };

 const clearHandler = (e) => {
  e.preventDefault();
  firstnameref.current.value = "";
  phonenumberref.current.value = "";
  emailref.current.value = "";
  dobref.current.value = "";
  genderref.current.value = "";
 };

 return (
  <>
   <h3 className="card-title mt-3 mb-3 comment text-white font-weight-bold text-center">
    Fill up the Form
   </h3>
   <form className="needs-validation p-1" onSubmit={submitHandler}>
    <Row>
     {/* <!-- FirstName --> */}
     <Col className="col-12 col-lg-4 mb-3 col-sm-12 col-md-6 ">
      <input
       type="text"
       className="form-control p-4 rounded-0 inputField border-0 "
       placeholder="First Name"
       id="firstname"
       ref={firstnameref}
       required
      />
     </Col>

     {/* <!-- PhoneNumber --> */}
     <Col className="col-12 col-lg-4 mb-3 col-sm-12 col-md-6">
      <input
       type="tel"
       className="form-control p-4 rounded-0 inputField border-0"
       placeholder="PhoneNumber"
       id="phonenumber"
       maxLength={10}
       ref={phonenumberref}
       required
      />
     </Col>
     {/* <!-- EmailAddress --> */}
     <Col className="col-12 col-lg-4 mb-3 col-sm-12 col-md-6">
      <input
       type="email"
       className="form-control p-4 rounded-0 inputField border-0"
       placeholder="EMAIL ADDRESS"
       id="email"
       ref={emailref}
       required
      />
     </Col>
     {/* <!-- DOB --> */}
     <Col className="col-12 col-lg-4 mb-3 col-sm-12 col-md-6">
      <input
       type="date"
       className="form-control p-4 rounded-0 inputField border-0"
       placeholder="Date of Birth"
       id="dob"
       ref={dobref}
       required
      />
     </Col>
     {/* <!-- Gender --> */}
     <Col className="col-12 col-lg-4 mb-3 col-sm-12 col-md-6">
      <select
       name="Gender"
       id="gender"
       className="container-fluid p-3 customSelect"
       ref={genderref}
       required>
       <option value="">Gender</option>
       <option value="Male">Male</option>
       <option value="Female">Female</option>
       <option value="Others">Others</option>
      </select>
     </Col>
    </Row>
    <Row className="text-center">
     <Col className="col-12 col-lg-6">
      <button
       className="btn w-100 mt-4 rounded-2 p-3 pl-4 pr-4 submitButton text-white font-weight-bold btn-primary"
       type="submit"
       id="submit">
       Next Page
      </button>
     </Col>
     <Col className="col-12 col-lg-6">
      <button
       className="btn w-100 mt-4 rounded-2 p-3 pl-4 pr-4 submitButton text-white font-weight-bold float-right bg-success"
       type="reset"
       onClick={clearHandler}>
       RESET FORM INPUTS
      </button>
     </Col>
    </Row>
   </form>
  </>
 );
};

export default FormContainer;
