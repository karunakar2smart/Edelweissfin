import { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { modal } from "../../Store/Slices/userSlice";

const ModalContainer = () => {
 const openModal = useSelector((state) => state.userSlice.openModal);
 const userDates = useSelector((state) => state.userSlice.userDates);
 const sundays = useSelector((state) => state.userSlice.sundays);
 const dispatch = useDispatch();

 const handleClose = () => {
  dispatch(modal());
 };

 return (
  <>
   <Modal show={openModal} onHide={handleClose}>
    <Modal.Header closeButton>
     <Modal.Title>Number of Sundays</Modal.Title>
    </Modal.Header>
    <Modal.Body>{`There are ${sundays} sundays in between ${userDates.firstDate} and ${userDates.secondDate}`}</Modal.Body>
    <Modal.Footer>
     <Button variant="secondary" onClick={handleClose}>
      Close
     </Button>
    </Modal.Footer>
   </Modal>
  </>
 );
};
export default ModalContainer;
