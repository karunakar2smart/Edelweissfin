import React from "react";
import { Container } from "react-bootstrap";

const Footer = () => {
 return (
  <>
   <footer className="m-0 text-white p-3 text-center fixed-bottom footerClass">
    <Container>
     <p>Made By Karunakar Patel</p>
     <p>@ Copyright 2022 All Rights Reserved Edelweissfin Company</p>
    </Container>
   </footer>
  </>
 );
};

export default Footer;
