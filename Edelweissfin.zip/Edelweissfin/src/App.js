import React from "react";
import { BrowserRouter } from "react-router-dom";
import RouterFile from "./Routes/RouterFile";
import "bootstrap/dist/css/bootstrap.min.css";

const App = () => {
 return (
  <>
   <BrowserRouter>
    <RouterFile />
   </BrowserRouter>
  </>
 );
};

export default App;
