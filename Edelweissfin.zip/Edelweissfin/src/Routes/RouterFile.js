import React from "react";
import { Route, Routes } from "react-router-dom";
import MainLayout from "../Components/Layouts/MainLayout";
import Datepicker from "../Components/Views/Datepicker";
import LandingPage from "../Components/Views/LandingPage";

const RouterFile = () => {
 return (
  <Routes>
   <Route path="/" element={<MainLayout />}>
    <Route index element={<LandingPage />} />
    <Route path="/datepicker" element={<Datepicker />} />
   </Route>
  </Routes>
 );
};

export default RouterFile;
