import { createSlice } from "@reduxjs/toolkit";

const initialState = {
 user: [],
 userDates: [],
 sundays: "",
 openModal: false,
};

function getNumberOfWeekDays(start, end, dayNum) {
 dayNum = dayNum || 0;
 var daysInInterval = Math.ceil(
  (end.getTime() - start.getTime()) / (1000 * 3600 * 24)
 );
 var toNextTargetDay = (7 + dayNum - start.getDay()) % 7;
 var daysFromFirstTargetDay = Math.max(daysInInterval - toNextTargetDay, 0);
 return Math.ceil(daysFromFirstTargetDay / 7);
}

const userSlice = createSlice({
 name: "userSlice",
 initialState: initialState,
 reducers: {
  storeSlice: (state, action) => {
   state.user = [...state.user, action.payload];
  },
  numberOfSundays: (state, action) => {
   state.userDates = action.payload;
   var start = new Date(state.userDates.firstDate);
   var finish = new Date(state.userDates.secondDate);
   state.sundays = getNumberOfWeekDays(start, finish);
   console.log(state.sundays, "Sundays");
  },
  modal: (state, action) => {
   state.openModal = !state.openModal;
  },
 },
});

export const { storeSlice, numberOfSundays, modal } = userSlice.actions;
export default userSlice.reducer;
